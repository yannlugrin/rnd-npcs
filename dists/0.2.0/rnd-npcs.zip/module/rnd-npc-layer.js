export class RndNpcLayer extends CanvasLayer
{
  
}