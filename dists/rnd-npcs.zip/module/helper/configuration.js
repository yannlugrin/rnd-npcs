//@ts-check

/**
 * Randomiser Configuration.
 */
export class RndConf
{
  /**
   * @member {string} - The technical name of the module.
   */
  static get SCOPE() { return 'rnd-npcs'; }
}
